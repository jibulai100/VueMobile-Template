export default {
  // petsInfo:{}//信息
}

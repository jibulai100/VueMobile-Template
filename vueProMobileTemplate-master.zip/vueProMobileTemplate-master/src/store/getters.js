/**
 * 数据计算对象
 */
export default {

}

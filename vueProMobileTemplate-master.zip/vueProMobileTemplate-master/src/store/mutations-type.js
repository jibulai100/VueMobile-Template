/**
 * 状态管理方法名
 */
/*export const RECEIVE_PETSINFO = 'receive_petsinfo'//接收信息*/
